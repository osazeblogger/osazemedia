<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

function author_stat_menu() {
	add_menu_page(
		'Author Stat page',
		'Author Stat',
		'manage_options',
		'author-stat-plugin',
		'author_stat_page',
		'dashicons-admin-users',
		6
	);
}

add_action( 'admin_menu', 'author_stat_menu' );

function author_stat_post_types() {
	$arr = array( 'post', 'page' );

	return apply_filters( 'author_stat_post_types', $arr );
}

function author_stat_page() {
	$number = 10;
	$date   = ( isset( $_GET["date"] ) ) ? sanitize_text_field( $_GET["date"] ) : false;
	$search = ( isset( $_GET["as"] ) ) ? sanitize_text_field( $_GET["as"] ) : false;
	$page   = ( isset( $_GET["paged"] ) ) ? (int) $_GET["paged"] : 1;
	$offset = ( $page - 1 ) * $number;
	?>
    <h2>Author Stat</h2>
    <div style="margin-bottom: 24px">
        <h2>Search authors by name</h2>
        <form method="get"
              action="<?php echo esc_url( add_query_arg( 'page', 'author-stat-plugin', admin_url( 'admin.php' ) ) ); ?>">
            <label for="as">Search</label>
            <input type="hidden" name="page" value="author-stat-plugin"/>
            <input type="text" name="as" aria-label="Search Authors" placeholder="Search Authors"/>
            <button type="submit" name="submit">Search Authors</button>
        </form>
		<?php
		if ( $search ) { ?>
            <h2>Search Results for: <em><?php echo $search; ?></em></h2>
            <a href="<?php echo esc_url( add_query_arg( 'page', 'author-stat-plugin', admin_url( 'admin.php' ) ) ); ?>">Back
                To Author Listing</a>
		<?php } ?>
    </div>
    <div>
        <form method="get"
              action="<?php echo esc_url( add_query_arg( 'page', 'author-stat-plugin', admin_url( 'admin.php' ) ) ); ?>">
            <input type="hidden" name="page" value="author-stat-plugin"/>
            <label for="as-date">Filters</label>
            <input type="date" value="<?php echo esc_attr( $date ); ?>" id="as-date" name="date">
            <input type="hidden" name="as" value="<?php echo esc_attr( $search ); ?>"/>
            <button type="submit" name="submit">Filter</button>
        </form>
    </div>
	<?php
	if ( $search ) {
		// Generate the query based on search field
		$users = new WP_User_Query(
			array(
				'role__not_in' => 'Subscriber',
				'search'       => '*' . $search . '*'
			) );
	} else {
		// Generate the query
		$users = new WP_User_Query(
			array(
				'role__not_in' => 'Subscriber',
				'offset'       => $offset,
				'number'       => $number
			) );
	}
	?>
	<?php
	// Get the total number of authors. Based on this, offset and number
	$total_authors = $users->total_users;

	// Calculate the total number of pages for the pagination
	$total_pages = intval( $total_authors / $number ) + 1;

	// The authors object.
	$authors = $users->get_results();
	?>
	<?php if ( ! empty( $authors ) ) { ?>
        <style>
            ul.author-stat, .author-stat ul {
                list-style-type: disc;
                padding: revert;
            }
        </style>
		<?php
		$post_types = author_stat_post_types();
		?>
		<?php if ( $date ) { ?>
			<?php
			$timestamp = strtotime( $date );
			?>
            <h2><?php echo esc_html( date( 'l, F d, Y', $timestamp ) ) ?></h2>
		<?php } ?>
        <ul class="author-stat">
			<?php
			foreach ( $authors as $author ) {
				$author_info = get_userdata( $author->ID );
				?>
                <li>
                    <h2>
                        <a href="<?php echo esc_url( get_author_posts_url( $author->ID ) ); ?>"><?php echo esc_html( $author_info->display_name ); ?></a>
                    </h2>
                    <ul>
						<?php if ( ! $date ) { ?>
                            <li>
                                <h3>Today</h3>
								<?php
								$i       = 0;
								$counter = count( $post_types );
								foreach ( $post_types as $post_type ) {
									$today = getdate();
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'year'  => $today['year'],
												'month' => $today['mon'],
												'day'   => $today['mday'],
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
                            <li>
                                <h3>This Week</h3>
								<?php
								$i       = 0;
								$counter = count( $post_types );
								foreach ( $post_types as $post_type ) {
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'year' => date( 'Y' ),
												'week' => date( 'W' ),
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
                            <li>
                                <h3>This Month</h3>
								<?php
								$i       = 0;
								$counter = count( $post_types );
								foreach ( $post_types as $post_type ) {
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'year'     => date( 'Y' ),
												'monthnum' => date( 'n' ),
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
                            <li>
                                <h3>Last 30 days</h3>
								<?php
								$i       = 0;
								$counter = count( $post_types );
								foreach ( $post_types as $post_type ) {
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'after'  => '-30 days',
												'column' => 'post_date',
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
                            <li>
                                <h3>This Year</h3>
								<?php
								$i       = 0;
								$counter = count( $post_types );
								foreach ( $post_types as $post_type ) {
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'year' => date( 'Y' )
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
						<?php } else { ?>
                            <li>
								<?php
								$i         = 0;
								$counter   = count( $post_types );
								$timestamp = strtotime( $date );
								$day       = date( 'd', $timestamp );
								$month     = date( 'm', $timestamp );
								$year      = date( 'Y', $timestamp );

								foreach ( $post_types as $post_type ) {
									$args  = array(
										'author'         => $author->ID,
										'posts_per_page' => 1,
										'post_type'      => $post_type,
										'post_status'    => 'publish',
										'fields'         => 'ids',
										'date_query'     => array(
											array(
												'year'  => $year,
												'month' => $month,
												'day'   => $day,
											),
										)
									);
									$query = new WP_Query( $args );
									$count = $query->found_posts;
									echo '<strong> ' . esc_html( $post_type ) . '</strong>' . ' (' . $count . ')';

									if ( ++ $i !== $counter ) {
										echo ' | ';
									}
								}
								?>
                            </li>
						<?php } ?>
                    </ul>

                </li>
				<?php
			}
			?>
        </ul>
		<?php
	} else {
		?>
        <h2>No authors found</h2>
		<?php
	}
	?>
    <nav id="nav-single" style="clear:both; float:none; margin-top:20px;">
		<?php if ( $page != 1 ) { ?>
            <span class="nav-previous"><a rel="prev" href="<?php echo add_query_arg( array(
					'page'  => 'author-stat-plugin',
					'paged' => $page - 1
				), admin_url( 'admin.php' ) ); ?>"><span
                            class="meta-nav">←</span> Previous</a></span>
		<?php } ?>

		<?php if ( $page < $total_pages ) { ?>
            <span class="nav-next" style="margin-left: 24px;"><a rel="next"
                                                                 href="<?php echo add_query_arg( array(
				                                                     'page'  => 'author-stat-plugin',
				                                                     'paged' => $page + 1
			                                                     ), admin_url( 'admin.php' ) ); ?>">Next <span
                            class="meta-nav">→</span></a></span>
		<?php } ?>
    </nav>
	<?php
}
