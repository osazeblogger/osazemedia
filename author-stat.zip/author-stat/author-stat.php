<?php

/**
 * Plugin Name: Author Stat
 * Plugin URI: https://osazemedia.com/
 * Description: Author Stat by Osaze Media shows how many posts an author made a day, week, month, and custom date range.
 * Version: 1.0
 * Author: OsazeMedia
 * Author URI: https://osazemedia.com/
 **/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$dir = plugin_dir_path( __FILE__ ) . 'inc/';

require_once $dir . 'admin.php';
